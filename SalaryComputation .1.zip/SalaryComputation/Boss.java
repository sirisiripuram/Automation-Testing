package SalaryComputation;

	//Boss.java
	public class Boss extends Employee {
	 double travelAllowance = 15;

	 public Boss(long employeeId, String employeeName, String employeeAddress, long employeePhone, double basicSalary) {
	     super(employeeId, employeeName, employeeAddress, employeePhone, basicSalary);
	 }

	 //public Boss(int employeeId, String employeeName, String employeeAddress, int employeePhone, int basicSalary) {
		// TODO Auto-generated constructor stub
	

	@Override
	 public void calculateSalary() {
	     double salary = basicSalary + (basicSalary * specialAllowance / 100) + (basicSalary * HRA / 100) + (basicSalary * travelAllowance / 100);
	     System.out.println("Salary (Boss): " + salary);
	 }
	}


