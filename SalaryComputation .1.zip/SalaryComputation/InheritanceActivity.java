package SalaryComputation;

//InheritanceActivity.java
public class InheritanceActivity {
    public static void main(String[] args) {
        Boss boss = new Boss(1, "John Doe", "123 Main St", 1234567890, 5000);
        Trainee trainee = new Trainee(2, "Jane Smith", "456 Oak St", 9876543210L, 3000);

        boss.calculateSalary(); // Calls overridden method in Boss class
        trainee.calculateSalary(); // Calls method in Employee class
    }
}